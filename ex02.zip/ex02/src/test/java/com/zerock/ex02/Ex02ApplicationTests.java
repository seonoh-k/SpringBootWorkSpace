package com.zerock.ex02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
